from flask import Flask, render_template, request
from flask_mysqldb import MySQL
import csv
app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Bosco@1998'
app.config['MYSQL_DB'] = 'school'

mysql = MySQL(app)
@app.route('/')
def index():
    return render_template('form.html')
@app.route('/submit', methods=['POST'])
def submit():
    # Get form data
    reg_num = request.form['reg_num']
    fullnames = request.form['fullnames']
    python = request.form['python']
    java = request.form['java']
    english = request.form['english']

    with open('student_marks.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([reg_num, fullnames, python,java,english])
    # Insert data into database
    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO students (reg_num,fullnames,python,java,english) VALUES (%s, %s, %s, %s, %s)", (reg_num, fullnames,python, java, english ))
    mysql.connection.commit()
    cur.close()

    return 'Data inserted successfully!'

if __name__ == '__main__':
    app.run(debug=True,port=4000)
