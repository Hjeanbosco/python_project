from flask import Flask, render_template, request, redirect, url_for, flash
from flask_mysqldb import MySQL
import csv
app = Flask(__name__)
app.secret_key = 'many random bytes'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Bosco@1998'
app.config['MYSQL_DB'] = 'school'

mysql = MySQL(app)



@app.route('/')
def Index():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM students")
    data = cur.fetchall()
    cur.close()


    return render_template('index2.html', students=data)



@app.route('/insert', methods = ['POST'])
def insert():

    if request.method == "POST":
        flash("Data Inserted Successfully")
        reg_num = request.form['reg_num']
        fullnames = request.form['fullnames']
        python = int(request.form['python'])
        java = int(request.form['java'])
        english = int(request.form['english'])

        total = python + java + english
        average = total / 3
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO students (reg_num, fullnames, python, java, english, total, average) VALUES (%s, %s,%s, %s,%s, %s, %s )", (reg_num, fullnames, python, java, english, total, average))
        mysql.connection.commit()

        with open('student_marks.csv', 'a', newline='') as file:
             writer = csv.writer(file)
             writer.writerow([reg_num, fullnames, python, java, english, total, average])

        return redirect(url_for('Index'))


if __name__ == "__main__":
    app.run(debug=True, port=4000)
