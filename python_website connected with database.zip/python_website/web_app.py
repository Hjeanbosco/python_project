from flask import Flask , render_template,request
app=Flask(__name__)
@app.route('/')
def message():
    #render("Welcome to my page of my website")
    return render_template('index.html')
@app.route('/home_name')
def my_name():
    return("Hello" + "bosco")

@app.route('/OWNER/<name>')
def my_nm(name):
    return('Hello Mr./Mrs'+name)

@app.route('/inputs_data')

def message_details():
    return render_template('user_inputs.html')
@app.route('/datails',methods=['POST'])
def message_det():
    Firstname=request.form['Firstname']
    Lastname=request.form['Lastname']
    Age=request.form['Age']
    fnn="Your details are:\n {},\n{},\n{},".format(Firstname,Lastname,Age)
    return render_template('user_details.html',Firstname=fnn,)



if(__name__=="__main__"):
    app.run(debug=True,port=4000)