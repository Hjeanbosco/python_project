from flask import Flask, render_template, request
import csv

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit():
    name = request.form['name']
    email = request.form['email']
    message = request.form['message']
    
    with open('data.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([name, email, message])
    
    return render_template('success.html')

if __name__ == '__main__':
    app.run(debug=True)