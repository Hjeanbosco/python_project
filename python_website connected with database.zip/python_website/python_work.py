from flask import Flask
from flask_mysqldb import MySQL

app=Flask(__name__)
app.config('MYSQL_HOST')=="localhost"
app.config('MYSQL_USER')=="root"
app.config('MYSQL_PASSWORD')=="Bosco@1998"
app.config('MYSQL_DB')=="python"
mysql=MySQL(app)
#CREATE CURSER
@app.route('/data')
def my_db_data():
    cur=mysql.connection.cursor()
    cur.execute("selec * from student")
    #cur.execute("insert into student(reg_no,marks) values(%s, %s),("20003","50")")


    mysql.connection.commit()
    data=cur.fetchall()
    return(str(data))
    #return("DATA INSERTED")
if __name__=="__main__":
    app.run(debug=True)