import mysql.connector
mysql=mysql.connector.connect(
host="localhost",
user="root",
password="     b",
database="python"
)
my_cursor=mysql.cursor()
sql="insert into student(reg_no,names) values(%s,%s)"
val=[
    ('3947563','peter'),
     ('39000063','kiki')
]
my_cursor.executemany(sql,val)
mysql.commit();
print('data inserted');