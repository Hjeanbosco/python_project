import mysql.connector
mydb = mysql.connector.connect(host="localhost",user="root",password="Bosco@1998",database="python")
mycursor = mydb.cursor()
mycursor.execute("select * from student")
result=mycursor.fetchall()
for i in mycursor:
    print(i)